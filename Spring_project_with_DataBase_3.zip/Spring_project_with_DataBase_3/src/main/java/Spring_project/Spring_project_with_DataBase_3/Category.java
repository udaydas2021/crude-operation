package Spring_project.Spring_project_with_DataBase_3;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Category {
@Id
int Category_id;
String Category_name;
String Category_city;
public int getCategory_id() {
	return Category_id;
}
public void setCategory_id(int category_id) {
	Category_id = category_id;
}
public String getCategory_name() {
	return Category_name;
}
public void setCategory_name(String category_name) {
	Category_name = category_name;
}
public String getCategory_city() {
	return Category_city;
}
public void setCategory_city(String category_city) {
	Category_city = category_city;
}
@Override
public String toString() {
	return "Category [Category_id=" + Category_id + ", Category_name=" + Category_name + ", Category_city="
			+ Category_city + "]";
}
public Category(int category_id, String category_name, String category_city) {
	super();
	Category_id = category_id;
	Category_name = category_name;
	Category_city = category_city;
}
public Category() {
	super();
	// TODO Auto-generated constructor stub
}
}
