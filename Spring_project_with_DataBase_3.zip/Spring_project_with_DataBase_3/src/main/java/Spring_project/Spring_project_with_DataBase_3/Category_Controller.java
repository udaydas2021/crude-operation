package Spring_project.Spring_project_with_DataBase_3;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Category_Controller {

	ArrayList<Category> al = new ArrayList<Category>();

	@Autowired
	SessionFactory sf;
	Category ft;

	
	
	@RequestMapping("One Record Showfaculty List")
	public Category oneRecord() {
		Session ss = sf.openSession();
		ft = ss.load(Category.class, 1);
		System.out.println(ft);
		return ft;

	}

	@RequestMapping("Multiple Record Showfaculty List")
	public List multipleRecord() {
		Session ss = sf.openSession();

		Criteria criteria = ss.createCriteria(Category.class);
		List<Category> facultyList = criteria.list();
		System.out.println(facultyList);

		return facultyList;

	}

	@GetMapping("get Multiple Record Showfaculty List")
	public List multipleRecord2() {
		Session ss = sf.openSession();

		Criteria criteria = ss.createCriteria(Category.class);
		List<Category> facultyList = criteria.list();
		System.out.println(facultyList);

		return facultyList;

	}

	@GetMapping("One Record Showfaculty List/{id}")
	public Category getFaculty(@PathVariable int id) {

		Session ss = sf.openSession();
		ft = ss.load(Category.class, id);
		System.out.println(ft);

		Category faculty = ft;
		for (Category Faculty : al) {
			if (Faculty.Category_id == id) {
				faculty = Faculty;
			}
		}
		System.out.println("One Record Show Successfully Done... " + faculty);
		return faculty;
	}

	@PostMapping("insertFaculty")
	Category addFaculty(@RequestBody Category Faculty) {

		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		// facultyname ff = new facultyname();

		ss.save(Faculty);
		System.out.println("Record Inserted Successfully Done... " + Faculty);
		tx.commit();
		return Faculty;
	}

	@PutMapping("updateFaculty")
	Category updateFaculty(@RequestBody Category Faculty) {

		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		// facultyname ff = new facultyname();

		ss.update(Faculty);
		System.out.println("Record Updated Successfully Done... " + Faculty);
		tx.commit();
		return Faculty;
	}

	

	@DeleteMapping("deleteFaculty/{id}")
	public int deleteFaculty(@PathVariable int id) {

		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		// facultyname faculty = null;
		ft = ss.load(Category.class, id);
		System.out.println(ft);

		ss.delete(ft);

		System.out.println("Record Deleted Successfully Done... " + id);
		tx.commit();
		return id;
	}

}
