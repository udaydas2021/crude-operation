package Spring_project.Spring_project_with_DataBase_3;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Products {
@Id
int Product_id;
String Product_name;
String Product_city;
public Products(int product_id, String product_name, String product_city) {
	super();
	Product_id = product_id;
	Product_name = product_name;
	Product_city = product_city;
}
public Products() {
	super();
	// TODO Auto-generated constructor stub
}
public int getProduct_id() {
	return Product_id;
}
public void setProduct_id(int product_id) {
	Product_id = product_id;
}
public String getProduct_name() {
	return Product_name;
}
public void setProduct_name(String product_name) {
	Product_name = product_name;
}
public String getProduct_city() {
	return Product_city;
}
public void setProduct_city(String product_city) {
	Product_city = product_city;
}
@Override
public String toString() {
	return "Products [Product_id=" + Product_id + ", Product_name=" + Product_name + ", Product_city=" + Product_city
			+ "]";
}
}
