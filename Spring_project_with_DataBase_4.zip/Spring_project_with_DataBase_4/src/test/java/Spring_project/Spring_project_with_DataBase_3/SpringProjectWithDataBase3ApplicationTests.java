package Spring_project.Spring_project_with_DataBase_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectWithDataBase3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
